
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/match.js
var DIFY_API_BASE = process.env.DIFY_API_BASE || "https://api.dify.ai";
var DIFY_WORKFLOW_URL = `${DIFY_API_BASE}/v1/workflows/run`;
var LIMIT_TOTAL = parseInt(process.env.USAGE_LIMIT_TOTAL || "100", 10);
var LIMIT_PER_IP = parseInt(process.env.USAGE_LIMIT_PER_IP || "10", 10);
var RESET_TOKEN = process.env.RESET_TOKEN || "";
var totalCalls = 0;
var ipCounts = /* @__PURE__ */ new Map();
function getClientIP(req) {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  return "0.0.0.0";
}
async function handler(req, context) {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: corsHeaders()
    });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const body = await req.json();
    const { resumeText, jdText, userApiKey } = body;
    const resetHeader = req.headers.get("x-reset-token");
    if (RESET_TOKEN && resetHeader === RESET_TOKEN) {
      totalCalls = 0;
      ipCounts.clear();
      return jsonResponse({ ok: true, message: "Counters reset", totalRemaining: LIMIT_TOTAL, ipRemaining: LIMIT_PER_IP });
    }
    if (!resumeText || !jdText) {
      return jsonResponse({ error: "Missing resumeText or jdText" }, 400);
    }
    const ip = getClientIP(req);
    if (totalCalls >= LIMIT_TOTAL) {
      return jsonResponse({
        error: "USAGE_LIMIT_REACHED",
        message: `\u8BD5\u7528\u6B21\u6570\u5DF2\u7528\u5B8C\uFF08\u603B\u8BA1 ${LIMIT_TOTAL} \u6B21\uFF09\uFF0C\u8BF7\u8054\u7CFB\u4F5C\u8005`,
        totalRemaining: 0,
        ipRemaining: LIMIT_PER_IP - (ipCounts.get(ip) || 0)
      }, 429);
    }
    const ipCount = ipCounts.get(ip) || 0;
    if (ipCount >= LIMIT_PER_IP) {
      return jsonResponse({
        error: "IP_LIMIT_REACHED",
        message: `\u8BE5\u8BBE\u5907\u8BD5\u7528\u6B21\u6570\u5DF2\u7528\u5B8C\uFF08\u6BCF\u8BBE\u5907 ${LIMIT_PER_IP} \u6B21\uFF09\uFF0C\u8BF7\u66F4\u6362\u7F51\u7EDC`,
        totalRemaining: LIMIT_TOTAL - totalCalls,
        ipRemaining: 0
      }, 429);
    }
    const serverKey = process.env.DIFY_API_KEY;
    const apiKey = userApiKey || serverKey;
    if (!apiKey) {
      return jsonResponse({ error: "No API key available" }, 500);
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6e4);
    const difyResponse = await fetch(DIFY_WORKFLOW_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        inputs: { resume: resumeText, JD: jdText },
        response_mode: "blocking",
        user: "resume-jd-matcher"
      }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!difyResponse.ok) {
      if (difyResponse.status === 401) return jsonResponse({ error: "API_KEY_INVALID" }, 401);
      if (difyResponse.status === 429) return jsonResponse({ error: "API_RATE_LIMITED" }, 429);
      return jsonResponse({ error: `API_ERROR_${difyResponse.status}` }, 502);
    }
    const json = await difyResponse.json();
    const outputs = json.data?.outputs;
    if (!outputs) {
      return jsonResponse({
        error: "API_RESPONSE_EMPTY",
        difyStatus: json.data?.status,
        difyError: json.data?.error,
        difyKeys: json.data ? Object.keys(json.data) : "no data"
      }, 502);
    }
    const result = outputs.result || outputs.text || outputs.output || outputs.json || Object.values(outputs).find((v) => typeof v === "string" || typeof v === "object");
    if (!result) {
      return jsonResponse({ error: "API_RESPONSE_EMPTY" }, 502);
    }
    let parsed;
    if (typeof result === "string") {
      if (/^(匹配|简历优化|技能补足)/m.test(result.trim())) {
        parsed = parseWorkflowOutput(result);
      } else {
        try {
          parsed = JSON.parse(result);
        } catch {
          const match = result.match(/```(?:json)?\s*([\s\S]*?)```/);
          if (match) {
            parsed = JSON.parse(match[1].trim());
          } else {
            return jsonResponse({ error: "API_RESPONSE_NOT_JSON" }, 502);
          }
        }
      }
    } else {
      parsed = result;
    }
    if (!parsed || typeof parsed !== "object") {
      return jsonResponse({ error: "API_RESPONSE_NOT_JSON" }, 502);
    }
    totalCalls++;
    ipCounts.set(ip, ipCount + 1);
    const quota = {
      totalRemaining: LIMIT_TOTAL - totalCalls,
      ipRemaining: LIMIT_PER_IP - (ipCount + 1),
      totalLimit: LIMIT_TOTAL,
      ipLimit: LIMIT_PER_IP
    };
    return jsonResponse({ ...parsed, quota }, 200);
  } catch (err) {
    if (err.name === "AbortError") {
      return jsonResponse({ error: "API_TIMEOUT" }, 504);
    }
    return jsonResponse({ error: "API_NETWORK_ERROR" }, 500);
  }
}
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Reset-Token"
  };
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders() }
  });
}
function parseWorkflowOutput(rawText) {
  try {
    return JSON.parse(rawText);
  } catch {
  }
  let matching = null;
  let resumeSuggestions = [];
  let skillSuggestions = [];
  const matchIdx = rawText.indexOf("\u5339\u914D");
  const optIdx = rawText.indexOf("\u7B80\u5386\u4F18\u5316");
  if (matchIdx !== -1) {
    const skillAt = rawText.indexOf("\u6280\u80FD\u8865\u8DB3");
    const endBoundary = [optIdx, skillAt].filter((i) => i > matchIdx).reduce((min, i) => Math.min(min, i), rawText.length);
    const section = rawText.substring(matchIdx + 2, endBoundary).trim();
    try {
      matching = JSON.parse(section);
    } catch {
    }
  }
  if (optIdx !== -1) {
    const skillIdx2 = rawText.indexOf("\u6280\u80FD\u8865\u8DB3");
    const optEnd = skillIdx2 !== -1 && skillIdx2 > optIdx ? skillIdx2 : rawText.length;
    const optSection = rawText.substring(optIdx, optEnd);
    const codeBlock = optSection.match(/```json\s*([\s\S]*?)\s*```/);
    if (codeBlock) {
      try {
        const o = JSON.parse(codeBlock[1]);
        resumeSuggestions = o.suggestions || [];
      } catch {
      }
    } else {
      const rawJson = optSection.match(/简历优化\s*(\{[\s\S]*)/);
      if (rawJson) {
        const js = rawJson[1];
        let d = 0, e = 0;
        for (let i = 0; i < js.length; i++) {
          if (js[i] === "{") d++;
          if (js[i] === "}") d--;
          if (d === 0) {
            e = i + 1;
            break;
          }
        }
        try {
          const o = JSON.parse(js.substring(0, e));
          resumeSuggestions = o.suggestions || [];
        } catch {
        }
      }
    }
  }
  const skillIdx = rawText.indexOf("\u6280\u80FD\u8865\u8DB3");
  if (skillIdx !== -1) {
    const section = rawText.substring(skillIdx + 4).trim();
    const braceStart = section.indexOf("{");
    if (braceStart !== -1) {
      const js = section.substring(braceStart);
      let d = 0, e = 0;
      for (let i = 0; i < js.length; i++) {
        if (js[i] === "{") d++;
        if (js[i] === "}") d--;
        if (d === 0) {
          e = i + 1;
          break;
        }
      }
      try {
        const s = JSON.parse(js.substring(0, e));
        skillSuggestions = s.skillSuggestions || [];
      } catch {
      }
    }
  }
  if (matching) return { ...matching, resumeSuggestions, skillSuggestions };
  throw new Error("API_RESPONSE_NOT_JSON");
}
export {
  handler as default
};
